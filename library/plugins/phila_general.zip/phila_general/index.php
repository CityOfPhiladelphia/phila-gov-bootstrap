<?php 	
/**
 * Plugin Name: Phila General Functionality
 * Plugin URI: 
 * Description: Provides Custom VC templates, widgets and other necessary functionality.
 * Version: .02
 * Author: Karissa Demi
 * Author URI: 
 */

$dir = plugin_dir_path( __FILE__ );

require $dir.'/inc/helpers.php';
require $dir.'/inc/VC_custom_templates.php';
require $dir.'/inc/VC_shortcodes.php';
require $dir.'taxonomies.php';
require $dir.'/widgets.php';
require $dir.'/customsidebars.php';
require $dir.'/media-tags.php';
require $dir.'/custom-menu.php';
require $dir.'/shortcodes.php';