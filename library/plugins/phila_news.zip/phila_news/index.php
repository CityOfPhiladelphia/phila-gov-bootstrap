<?php 	// hush
$dir = plugin_dir_path( __FILE__ );

require $dir.'/phila_news.php';